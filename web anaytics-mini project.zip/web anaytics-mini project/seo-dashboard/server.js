const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

app.post('/analyze', async (req, res) => {
  const { url } = req.body;

  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);

    const title = $('title').text() || 'Missing';
    const metaDesc = $('meta[name="description"]').attr('content') || 'Missing';
    const h1Tags = $('h1').length;
    const images = $('img');
    const imagesWithoutAlt = images.filter((i, img) => !$(img).attr('alt')).length;

    const mobileFriendly = response.data.includes('viewport');

    const seoScore = calculateSEOScore({
      title,
      metaDesc,
      h1Tags,
      imagesWithoutAlt,
      mobileFriendly,
    });

    res.json({
      title,
      metaDesc,
      h1Tags,
      imagesWithoutAlt,
      mobileFriendly,
      seoScore
    });

  } catch (error) {
    res.status(500).json({ error: 'Error analyzing URL. Please check if it is correct.' });
  }
});

function calculateSEOScore(data) {
  let score = 100;

  if (data.title === 'Missing') score -= 15;
  if (data.metaDesc === 'Missing') score -= 15;
  if (data.h1Tags === 0) score -= 10;
  if (data.imagesWithoutAlt > 0) score -= data.imagesWithoutAlt * 2;
  if (!data.mobileFriendly) score -= 20;

  return Math.max(score, 0);
}

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
