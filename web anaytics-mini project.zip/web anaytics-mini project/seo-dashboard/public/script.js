async function analyzeSEO() {
  const url = document.getElementById('urlInput').value;
  const resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = 'Analyzing...';

  try {
    const res = await fetch('/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });

    const data = await res.json();

    if (data.error) {
      resultsDiv.innerHTML = `<p style="color:red;">${data.error}</p>`;
    } else {
      resultsDiv.innerHTML = `
        <p><strong>Title:</strong> ${data.title}</p>
        <p><strong>Meta Description:</strong> ${data.metaDesc}</p>
        <p><strong>H1 Tags Count:</strong> ${data.h1Tags}</p>
        <p><strong>Images Missing ALT:</strong> ${data.imagesWithoutAlt}</p>
        <p><strong>Mobile Friendly:</strong> ${data.mobileFriendly ? 'Yes' : 'No'}</p>
        <p><strong>SEO Score:</strong> ${data.seoScore} / 100</p>
      `;
    }
  } catch (err) {
    resultsDiv.innerHTML = `<p style="color:red;">Error fetching data.</p>`;
  }
}
